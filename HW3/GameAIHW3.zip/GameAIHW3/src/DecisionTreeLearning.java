import java.io.File;
import java.util.*;

public class DecisionTreeLearning {

	List<String[]> data_list;
	
	public void getData()
	{
		try
		{
			File reader = new File("Output.txt");
			Scanner sc = new Scanner (reader);
			
			data_list = new ArrayList<String[]>();
		
			while(sc.hasNextLine())
			{
				String[] line = sc.nextLine().split(",");
				int dist = Integer.parseInt(line[1]);
				data_list.add(new String[]{line[0], dist < 250 ? dist < 10 ? "closest":"close":"far",line[2]});
			}
			sc.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	
	public float getImpurityEntropy(List<String[]> list, int attr)
	{
		Map<String, Map<String, Integer>> mapString = new HashMap<String, Map<String, Integer>>();
		
		for (String[] data: list)
		{
			if (mapString.containsKey(data[attr]))
			{
				Map<String, Integer> indi_map = mapString.get(data[attr]);
				if(indi_map.containsKey(data[2]))
				{
					indi_map.put(data[2], indi_map.get(data[2])+1);
				}
				else
				{
					indi_map.put(data[2], 1);
				}
				mapString.put(data[attr], indi_map);
			}
			else
			{
				Map<String, Integer> indi_map = new HashMap<String, Integer>();
				indi_map.put(data[2], 1);
				mapString.put(data[attr], indi_map);
			}
		}
		
		float impurity = 0;
		int size = list.size();
		
		for (Map.Entry<String, Map<String, Integer>> entry:mapString.entrySet())
		{
			List<Integer> lint = new ArrayList<Integer>();
			int total = 0;
			for (Map.Entry<String, Integer> entry_2 : entry.getValue().entrySet())
			{
				lint.add(entry_2.getValue());
				total += entry_2.getValue();
			}
			float imp = 0;
			for (Integer val:lint)
			{
				imp -= ((float) val/total)*(Math.log((float)val/total)/(Math.log(2))); 
			}
			impurity += ((float) total/size)*imp;
		}
		return impurity;
	}
}
