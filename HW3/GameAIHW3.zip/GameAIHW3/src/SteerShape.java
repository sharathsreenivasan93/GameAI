import processing.core.PVector;

public class SteerShape {
	
	PVector char_pos;
	PVector linear;
	PVector goal_vel;
	PVector char_vel;
	PVector direction;
	float max_vel;
	float r_s;
	float r_d;
	float time_to_target_vel;
	float goal_speed;
	float r;
	SteerShape(float x, float y)
	{
		char_pos = new PVector(x,y);
		linear = new PVector(0,0);
		goal_vel = new PVector(0,0);
		char_vel = new PVector(0,0);
		direction = new PVector(0,0);
		max_vel = 2;
		r_s = 20;
		r_d = 80;
		time_to_target_vel = 3;
		r = 5;
	}

}
