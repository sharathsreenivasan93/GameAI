import java.util.*;

public class DecisionBehavior {
	
	//public boolean conditionCheck(float x, float y)
	//{
	//	return false;
	//}
	
	public boolean selectNode(BehaviorTree node)
	{
		return false;
	}
	
	public DTLNode childSelect(DTLNode node)
	{
		return null;
	}
	
	public class DistanceDecide extends DecisionBehavior
	{
		public DTLNode childSelect(DTLNode node)
		{
			float distance = Part_3.monster.char_pos.dist(Part_3.shape.char_pos);
			
			if (distance < 10)
			{
				return node.children.get(0);
			}
			else
			{
				DTLNode child = node.children.get(1);
				if (child.decision !=null)
					return child.decision.childSelect(child);
				else
					return child;
			}
		}
	}
	
	public class CheckVicinity extends DecisionBehavior
	{
		public DTLNode childSelect(DTLNode node)
		{
			float distance = Part_3.monster.char_pos.dist(Part_3.shape.char_pos);
			
			if(distance < 250){
				return node.children.get(0);
			} else {
				return node.children.get(1);
			}
		}
	}
	
	public class Selector extends DecisionBehavior
	{
		public boolean selectNode(BehaviorTree node)
		{
			for (BehaviorTree child:node.children)
			{
				if (child.children.size() > 0){
					if (child.decision.selectNode(child))
						return true;
				}
				else{
					if (child.action.implementAction())
						return true;
				}
			}
			return false;
		}
	}
	public class RandomSelector extends DecisionBehavior
	{
		public boolean selectNode(BehaviorTree node)
		{
			
			ArrayList<BehaviorTree> list = new ArrayList<BehaviorTree>();
			list.addAll(node.children);
			
			Collections.shuffle(list);
			for(BehaviorTree child : list){
				if(child.children.size() > 0){
					if(child.decision.selectNode(child))
						return true;
				} else {
					if(child.action.implementAction())
						return true;
				}
			}
			
			return false;
		}
	}
	public class Sequencer extends DecisionBehavior{
		
		public boolean selectNode(BehaviorTree node){
			
			for(BehaviorTree child : node.children){
				if(child.children.size() > 0){
					if(!child.decision.selectNode(child))
						return false;
				} else {
					if(!child.action.implementAction())
						return false;
				}
			}
			
			return true;
		}
	}
}
