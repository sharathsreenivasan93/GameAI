import processing.core.PApplet;
import processing.core.PVector;


import javax.swing.JOptionPane;

public class Part_3 extends PApplet{
	
		void update()
		{
			shape.char_vel.add(shape.linear);
		    shape.char_vel.limit(shape.max_vel);
		    shape.char_pos.add(shape.char_vel);
		    shape.linear.mult(0);
		}
		void arrive(PVector target_pos, SteerShape sh)
		{
			 float distance;
			    //println(target_pos);
			    //println(char_pos);
			    shape.direction = PVector.sub(target_pos,shape.char_pos);
			    distance = sqrt(pow((target_pos.x-shape.char_pos.x),2) + pow((target_pos.y-shape.char_pos.y),2));
			    //println("Distance"+distance);
			    if (distance < sh.r_s)
			    {
			      shape.linear = shape.char_vel.mult(-1);
			      shape.linear = shape.linear.mult(1/shape.time_to_target_vel);
			      if (pointer1 < 27)
			    	  pointer1 = pointer1 + 1;
			      //println("Path Counter"+path_counter);
			    }
			    if (distance > sh.r_d)
			      shape.goal_speed = shape.max_vel;
			    
			    else
			      shape.goal_speed = (shape.max_vel*distance)/shape.r_d;
			     shape.goal_vel = shape.direction;
			     shape.goal_vel.normalize();
			     shape.goal_vel.mult(shape.goal_speed);
			     shape.linear = PVector.sub(shape.goal_vel,shape.char_vel);
			     update();
		}
		void display(int x, SteerShape sh)
		{
			float theta = shape.char_vel.heading()-PI/2;
		    fill(x);
		    stroke(x);
		      //ellipse(target_pos.x,target_pos.y,10,10);
		      //triangle(target_pos.x,target_pos.y-r_s,target_pos.x,target_pos.y+r_s,target_pos.x+50,target_pos.y);
		    pushMatrix();
		    translate(shape.char_pos.x,shape.char_pos.y);
		    rotate(theta);
		    beginShape();
		    ellipse(0,0,2*sh.r,2*sh.r);
		    vertex(sh.r,0);
		    vertex(-sh.r,0);
		    vertex(0,2*sh.r);
		    endShape(CLOSE);
		    popMatrix();
		}
		void arrive_monster(PVector target_pos, SteerShape sh)
		{
			 float distance;
			    //println(target_pos);
			    //println(char_pos);
			    monster.direction = PVector.sub(target_pos,monster.char_pos);
			    distance = sqrt(pow((target_pos.x-monster.char_pos.x),2) + pow((target_pos.y-monster.char_pos.y),2));
			    //println("Distance"+distance);
			    if (distance < sh.r_s)
			    {
			      monster.linear = monster.char_vel.mult(-1);
			      monster.linear = monster.linear.mult(1/monster.time_to_target_vel);
			      //if (pointer1 < 27)
			    	//  pointer1 = pointer1 + 1;
			      //println("Path Counter"+path_counter);
			    }
			    if (distance > sh.r_d)
			      monster.goal_speed = monster.max_vel;
			    
			    else
			      monster.goal_speed = (monster.max_vel*distance)/monster.r_d;
			     monster.goal_vel = monster.direction;
			     monster.goal_vel.normalize();
			     monster.goal_vel.mult(monster.goal_speed);
			     monster.linear = PVector.sub(monster.goal_vel,monster.char_vel);
			     update_monster();
		}
		void update_monster()
		{
			monster.char_vel.add(monster.linear);
		    monster.char_vel.limit(monster.max_vel);
		    monster.char_pos.add(monster.char_vel);
		    monster.linear.mult(0);
		}
		void display_monster(int x, SteerShape sh)
		{
			float theta = monster.char_vel.heading()-PI/2;
		    fill(x);
		    stroke(x);
		      //ellipse(target_pos.x,target_pos.y,10,10);
		      //triangle(target_pos.x,target_pos.y-r_s,target_pos.x,target_pos.y+r_s,target_pos.x+50,target_pos.y);
		    pushMatrix();
		    translate(monster.char_pos.x,monster.char_pos.y);
		    rotate(theta);
		    beginShape();
		    ellipse(0,0,2*sh.r,2*sh.r);
		    vertex(sh.r,0);
		    vertex(-sh.r,0);
		    vertex(0,2*sh.r);
		    endShape(CLOSE);
		    popMatrix();
		}
		void display_monster_funny(SteerShape sh)
		{
			float theta = monster.char_vel.heading()-PI/2;
		    fill(0);
		    stroke(0);
		      //ellipse(target_pos.x,target_pos.y,10,10);
		      //triangle(target_pos.x,target_pos.y-r_s,target_pos.x,target_pos.y+r_s,target_pos.x+50,target_pos.y);
		    pushMatrix();
		    translate(monster.char_pos.x,monster.char_pos.y);
		    rotate(theta);
		    beginShape();
		    ellipse(0,0,4*sh.r,4*sh.r);
		    vertex(sh.r,0);
		    vertex(-sh.r,0);
		    vertex(0,2*sh.r);
		    endShape(CLOSE);
		    popMatrix();
		}

	int[] arr={30,30, 550,30, 450,30, 300,100, 
            75,200, 300,350, 450,175, 151,350, 
            15,330, 15,380, 450,350, 575,325,
            575,380, 300,500, 100,500, 550,500,
            100,700, 300,700, 550,700, 450,250,
            550,250, 15,275, 15,425, 575,420,
            575,275, 175,425, 220,300, 450,450};
	int []edges = {0,4, 0,3, 4,3, 3,2, 3,6, 2,1,
                2,6, 6,19, 6,20, 19,10, 19,20, 5,7,
                5,10, 5,13, 10,11, 10,12, 11,12, 13,14,
                13,15, 14,16, 16,17, 17,18, 15,18, 7,8,
                7,9, 8,9, 19,5, 4,21, 14,22, 15,23, 20,24,
                14,25, 4,26, 5,26, 5,27, 5,25, 7,26, 27,15,
                23,27, 10,27};
	float [][]adj_mat=new float[arr.length][arr.length];
	PVector[] nodes=new PVector[arr.length/2];
	PVector target_pos, source, inter_target;
	static SteerShape shape=new SteerShape(25,25);
	static SteerShape monster = new SteerShape(400,100);
	DTLNode root;
	PVector mouse=new PVector();
	PVector node = new PVector();
	int pointer1, pointer2;
	int cur_pos, source_pos;
	int[] open_list = new int[arr.length/2];
	int[] close_list = new int[arr.length/2];
	int [][]path=new int[arr.length][arr.length];
	int current;
	static int flag = 1;
	int count = 0;
	static int leaf_type = 0;
	float distance2;
	
	public void settings()
	{
		size(600,800);
	}
	public void setup()
	{
		target_pos= new PVector(0,0);
		settings();
		stroke(0,0,255);
		source = new PVector(30,30);
		inter_target = new PVector(25,25);  
		root = learnDecisionTree();
	}
	public DTLNode learnDecisionTree()
	{
		DecisionTreeLearning dTL = new DecisionTreeLearning();
		dTL.getData();
		
		float impurity1 = dTL.getImpurityEntropy(dTL.data_list, 0);
		float impurity2 = dTL.getImpurityEntropy(dTL.data_list, 1);
		
		DTLNode root = null;
		AllAction action = new AllAction();
		DecisionBehavior decision = new DecisionBehavior();
		
		if (impurity1 < impurity2)
		{
			root = new DTLNode(decision.new CheckVicinity());
			root.children.add(new DTLNode(decision.new DistanceDecide()));
			root.children.add(new DTLNode(action.new BlinkFunny()));
			
			root.children.get(1).children.add(new DTLNode(action.new Eat()));
			root.children.get(1).children.add(new DTLNode(action.new Seek()));
		}
		else
		{
			root = new DTLNode(decision.new DistanceDecide());
			root.children.add(new DTLNode(action.new Eat()));
			root.children.add(new DTLNode(decision.new CheckVicinity()));
			
			root.children.get(1).children.add(new DTLNode(action.new Seek()));
			root.children.get(1).children.add(new DTLNode(action.new BlinkFunny()));
		}
		return root;
	}
	public int localization(PVector position)
	{
		float least = Float.MAX_VALUE;
		int i=0, node_cur=0;
		for(i=0;i<nodes.length;i++)
	     {
	       float distance = PVector.dist(position,nodes[i]);
	       if (distance < least)
	       {
	         least = distance;
	         node_cur = i;
	       }
	     }
		fill(0,0,255);
		ellipse(nodes[node_cur].x,nodes[node_cur].y,10,10);
		return node_cur;
	}
	public void aStar(int source, int dest)
	{
		float []shortest =new float[arr.length/2];
		float []estimated=new float[arr.length/2];
		
		for(int i=0;i<arr.length/2;i++)
		{
		      shortest[i]=Integer.MAX_VALUE;
		      estimated[i]=Integer.MAX_VALUE;
		      open_list[i]=0;
		      close_list[i]=0;
		      for (int j=0;j<arr.length/2;j++)
		        path[i][j]=-1;
		}
		int current=source;
		shortest[source]=0;
		open_list[source]=1;
		path[source][0]=source;
		estimated[source]=PVector.dist(nodes[source],nodes[dest]);
		float heuristics, sum;
		while(current!=dest)
		{
			for(int i=0;i<arr.length/2;i++)
			{
				if((adj_mat[current][i]!=Integer.MAX_VALUE)&&(adj_mat[current][i]>0)&&(close_list[i]!=1))//edge exists
				{
					heuristics = PVector.dist(nodes[i],nodes[dest]);
					sum = shortest[current]+adj_mat[current][i] + heuristics;
					if(sum<estimated[i])
					{
						int j;
						estimated[i] = sum;
						shortest[i]=sum-heuristics;
						 for (j=0;path[current][j]!=-1;j++)
			                  path[i][j] = path[current][j];
			             path[i][j]=i;
					}
					open_list[i] = 1;
				}
			}
			close_list[current]=1;
	        open_list[current]=0;
	        float least =Float.MAX_VALUE;
	        for(int r=0;r<arr.length/2;r++)
	        {
	            if((open_list[r]==1)&&(estimated[r]<least))
	            {
	                least=estimated[r];
	                current =r;
	            }
	         }
		}
		
	}
	public void draw()
	{
		DTLNode node = root.decision.childSelect(root);
		node.action.implementAction();
		int i,index=0;
		stroke(0,0,0);
		fill(0);
		background(255);
		//bathroom 1
		rect(0,300,150,10);
		rect(0,400,150,10);
		rect(150,300,5,30);
		rect(150,380,5,30);
		   
		//staircase
		rect(500,50,100,125);
		   
		//storeroom
		rect(500,300,100,10);
		rect(500,400,100,10);
		   
		//kitchen table
		rect(150,550,350,100);
		   
		//drawing-room table
		rect(250,150,100,100);
		for (i=0;i<arr.length;i=i+2)
		{
			nodes[index]=new PVector(arr[i],arr[i+1]);
		    index++;
		}   
		for (i=0;i<arr.length;i=i+2)
		{
		    ellipse(arr[i],arr[i+1],10,10);
		}
		for (i=0;i<arr.length;i++)
		{
			for (int j=0;j<arr.length;j++)
			{
				if (i==j)
					adj_mat[i][j]=0;
		        else
		        	adj_mat[i][j]=Float.MAX_VALUE;
		    }
		}
		for(i=0;i<edges.length;i+=2)
		{
			PVector n1 =nodes[edges[i]];
		    PVector n2 =nodes[edges[i+1]];
		    line(n1.x,n1.y,n2.x,n2.y);
		    adj_mat[edges[i]][edges[i+1]] = PVector.dist(n1,n2);
		    adj_mat[edges[i+1]][edges[i]] = PVector.dist(n1,n2);
		}
		source_pos = localization(shape.char_pos);
		if (mousePressed == true)
		{
			target_pos = new PVector(mouseX, mouseY);
			source_pos = localization(shape.char_pos);
			cur_pos = localization(target_pos);
			if (source_pos!=cur_pos)
			{
				pointer1 = 0;
				pointer2 = 0;
				aStar(source_pos,cur_pos);
			}
		}
		int z = 0;
		while (path[cur_pos][z]!=-1 && z < arr.length/2)
		{
			ellipse(nodes[path[cur_pos][z]].x, nodes[path[cur_pos][z]].y, 10, 10);
			z++;
		}
		pointer2 = z;
		current = localization(shape.char_pos);
		if (current !=cur_pos && pointer1<pointer2 && path[cur_pos][pointer1]!=-1)
			inter_target = nodes[path[cur_pos][pointer1]];
		else
			inter_target = target_pos;
		
		arrive(inter_target, shape);
		display(0, shape);
	
		//monster.arrive_monster(shape.char_pos);
		display_monster(0, monster);
		if (leaf_type == 1)
		{
			if (flag == 1)
			{
				display_monster(200, monster);
				flag = -1;
			}
			else
			{
				display_monster(0, monster);
				flag = 1;
			}
		}
		// Displaying funny
		else if (leaf_type == 2)
		{
			count = count + 1;
			if (count == 10)
			{
				display_monster_funny(monster);
				count = 1;
			}
		}
		//eating
		else if (leaf_type == 4)
		{
				JOptionPane.showMessageDialog(null,"Character has been eaten");
				shape.char_pos =new  PVector(25,25);
				monster.char_pos =new PVector(400,100);
				path=new int[arr.length][arr.length];
				//aStar(1,1);
				leaf_type = 0;
		}
		else if (leaf_type == 3)
		{
			arrive_monster(shape.char_pos,monster);
			display_monster(100,monster);
		}
		
	}
	public static void main(String args[]) {
		PApplet.main(new String[] { "--present", "Part_3"});
	}

}
