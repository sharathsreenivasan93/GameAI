
public enum Behavior_NodeType {
	SELECTOR, RANDOM_SELECTOR, SEQUENCER, ACTION
}
