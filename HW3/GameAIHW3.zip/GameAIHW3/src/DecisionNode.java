import processing.core.PVector;

public class DecisionNode {
	DecisionNode left;
	DecisionNode right;
	int type;
	boolean checkX;
	float xval;
	float yval;
	
	public DecisionNode(boolean checkX, float xval, float yval)
	{
		this.checkX=checkX;
		this.xval=xval;
		this.yval=yval;
	}
	
	DecisionNode(int type)
	{
		this.type=type;
	}
	
	public DecisionNode decisionMake(float x, float y)
	{
		DecisionNode result = null;
		if (checkX)
		{
			if (x < xval)
				result = left;
			else
				result = right;
		}
		else
		{
			if (y < yval)
				result = left;
			else
				result = right;
		}
		return result;
	}
	
}
