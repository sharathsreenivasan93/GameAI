import java.util.*;

public class BehaviorTree 
{
	public Behavior_NodeType type;
	ArrayList<BehaviorTree> children;
	DecisionBehavior decision;
	AllAction action;
	
	public BehaviorTree(Behavior_NodeType nodeType, DecisionBehavior decision)
	{
		children = new ArrayList<BehaviorTree>();
		type = nodeType;
		this.decision = decision;
	}
	public BehaviorTree(Behavior_NodeType nodeType, AllAction action)
	{
		children = new ArrayList<BehaviorTree>();
		type = nodeType;
		this.action = action;
	}
}
