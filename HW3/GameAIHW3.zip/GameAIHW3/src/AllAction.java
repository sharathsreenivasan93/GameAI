import java.util.*;
import processing.core.*;

public class AllAction {
	
	public boolean implementAction()
	{
		return false;
	}
	
	public class BlinkFunny extends AllAction{
		public boolean implementAction(){
			double random = Math.random();
			if (random > 0.5)
				Part_3.leaf_type = 1;
			else
				Part_3.leaf_type = 2;
			return true;
		}
	}
	
	
	public class Seek extends AllAction{
		public boolean implementAction(){
			Part_3.leaf_type = 3;
			return true;
		}
	}
	
	public class Eat extends AllAction{
		public boolean implementAction(){
				Part_3.leaf_type = 4;
				return true;
		}
	}
	
	
	public class BlinkAction extends AllAction{
		public boolean implementAction(){
			Part_2.leaf_type = 1;
			float distance2 = PVector.dist(Part_2.shape.char_pos,Part_2.monster.char_pos);
			Part_2.log(false, (int)distance2, "Blink");
			return true;
		}
	}
	
	public class DisplayFunny extends AllAction{
		public boolean implementAction(){
			Part_2.leaf_type = 2;
			float distance2 = PVector.dist(Part_2.shape.char_pos,Part_2.monster.char_pos);
			Part_2.log(false, (int)distance2, "Display");			
			return true;
		}
	}
	
	public class SeekAction extends AllAction{
		public boolean implementAction(){
			Part_2.leaf_type = 3;
			float distance2 = PVector.dist(Part_2.shape.char_pos,Part_2.monster.char_pos);
			if (distance2 > 10)
			{
				Part_2.log(true, (int)distance2, "Seek");
			}
			return true;
		}
	}
	
	public class EatAction extends AllAction{
		public boolean implementAction(){
			float distance2 = PVector.dist(Part_2.shape.char_pos,Part_2.monster.char_pos);
			if (distance2 < 10)
			{
				Part_2.leaf_type = 4;
				Part_2.log(true, (int)distance2, "Eat");
				return true;
			}
			else
			{
				return true;
			}	
		}
	}
	
	public class CheckVicinity extends AllAction{
		public boolean implementAction ()
		{
			float distance2 = PVector.dist(Part_2.shape.char_pos,Part_2.monster.char_pos);
			if(distance2 < 250)
				return true;
			else
				return false;
		}
	}
}
