import java.util.ArrayList;

public class DTLNode {
	ArrayList<DTLNode> children;
	DecisionBehavior decision;
	AllAction action;
	
	public DTLNode(DecisionBehavior decision)
	{
		children = new ArrayList<DTLNode>();
		this.decision = decision;
	}
	public DTLNode(AllAction action)
	{
		children = new ArrayList<DTLNode>();
		this.action = action;
	}
}
